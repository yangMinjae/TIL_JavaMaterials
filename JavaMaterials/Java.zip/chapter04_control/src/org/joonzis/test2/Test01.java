package org.joonzis.test2;

public class Test01 {

	public static void main(String[] args) {
		for(int i=10;i>0;i--) {
			System.out.println(i);
		}
	}

}
