package org.joonzis.ex;

public class Ex04_ {
	//두 값을 이용하여 사칙 연산을 하는 클래스
	
	// 1. 두 값을 전달받아 두 값의 합을 출력하는 plus 메소드
	// 2. 전역 변수 두 개의 차를 출력하는 minus 메소드
	// 3. 전역 변수 두 개의 곱을 출력하는 multi 메소드
	// 4. 전역 변수 두 개의 나눈 값을 리턴하는 div 메소드
	double val1, val2;
	Ex04_(int val1, int val2){
		this.val1=val1;
		this.val2=val2;
	}
	double plus() {
		return this.val1+this.val2;
	}
	double minus() {
		return this.val1-this.val2;
	}
	double multi() {
		return this.val1*this.val2;
	}
	double div() {
		return this.val1/this.val2;
	}

	void printCalc() {
		System.out.printf("합 : %.2f + %.2f = %.2f%n",this.val1, this.val2,this.plus());
		System.out.printf("차 : %.2f - %.2f = %.2f%n",this.val1, this.val2,this.minus());
		System.out.printf("곱셈 : %.2f x %.2f = %.2f%n",this.val1, this.val2,this.multi());
		System.out.printf("나눗셈 : %.2f / %.2f = %.2f%n",this.val1, this.val2,this.div());
	}
	public static void main(String[] args) {
		Ex04_ ex= new Ex04_(6, 8);
		ex.printCalc();
	}
}
