package src.org.joonzis.ex;

public class Ex01_Variable {
	public static void main(String[] args) {
		
		// 주석 : 실행과 상관없이 코드에 설명을 붙이는 것
		// 1. // : // 이후 라인 끝까지 주석으로 인지
		// 2. /**/ : 사이에 있는 모든 범위를 주석으로 인지
		
		// 1. 변수 선언( 선언과 초기화 동시 진행 )
		int num = 0;
		float num2 = 0f;
		double num3 = 0;
		char ch = 0;
		char ch2 = 'a';
		int ch3 = 'a';
		String str1 = null;
		String str2 = "hi";
		
		System.out.println(num);
		System.out.println(num2);
		System.out.println(num3);
		System.out.println(ch);
		System.out.println(ch2);
		System.out.println(ch3);
		System.out.println(str1);
		System.out.println(str2);
		
		
	}
}





